using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Code
{
    public class Player : MonoBehaviour
    {
        private Rigidbody2D _rb;
        public float moveSpeed = 5.0f;
        public bool canJump = false;
        public AudioSource scoreSound;
        public AudioSource dieSound;
        public bool horizontalMovement;
        Animator animator;

        // Start is called before the first frame update
        void Start()
        {
            _rb = GetComponent<Rigidbody2D>();
            scoreSound = GetComponent<AudioSource>();
            dieSound = GetComponent<AudioSource>();
            animator = GetComponent<Animator>();    
        }

        // Update is called once per frame
        void Update()
        {
            horizontalMovement = (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.RightArrow));
           
            if (_rb.position.y < -10.5)
            {
                ResetLevel();
            }

            if (Input.GetKey(KeyCode.LeftArrow) && _rb.position.x > -17)
            {
                Move(Vector2.left);
                GetComponent<SpriteRenderer>().flipX = true;
            }
            else if (Input.GetKey(KeyCode.RightArrow))
            {
                Move(Vector2.right);
                GetComponent<SpriteRenderer>().flipX = false;

            }
            if ((Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.Space)) && canJump)
            {
                Move(Vector2.up);
                canJump = false;
            }
            else if (Input.GetKeyDown(KeyCode.DownArrow))
            {
                Move(Vector2.down);
            }
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                ResetLevel();
            }

        }

        private void Move(Vector2 direction)
        {
            // Calculate the movement vector
            Vector2 movement = direction * moveSpeed;

            // Apply the movement to the Rigidbody
            _rb.velocity = movement;
        }

        private void ResetLevel()
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
        void OnCollisionEnter2D(Collision2D collision)
        {
            // TODO
            if (collision.collider.gameObject.GetComponent<Ground>())
            {
                canJump = true;
            }

            if (collision.collider.gameObject.GetComponent<Enemy>())
            {
                UI.GameOver(false);
                dieSound.Play();

                ResetLevel();
            }

            if (collision.collider.gameObject.GetComponent<Totem>())
            {
                scoreSound.Play();
            }
        }

    }
}


