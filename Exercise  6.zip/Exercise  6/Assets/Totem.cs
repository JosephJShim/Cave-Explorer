using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace Code
{
    public class Totem : MonoBehaviour
    {
        // Start is called before the first frame update
        void Start()
        {
        
        }

        // Update is called once per frame
        void Update()
        {
        
        }

        void OnCollisionEnter2D(Collision2D collision)
        {
            // TODO
            if (collision.collider.gameObject.GetComponent<Player>())
            {
                UI.IncrementScore();
                Destroy(gameObject);
            }
        }
    }

}

