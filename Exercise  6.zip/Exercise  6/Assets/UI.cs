using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;


namespace Code
{
    public class UI : MonoBehaviour
    {

        public static UI Singleton;
        public TextMeshProUGUI scoreText;
        public TextMeshProUGUI gameOverText;
        private int _score = 0;

        // Start is called before the first frame update
        void Start()
        {
            Singleton = this;
            scoreText.text = "Score: 0";
            gameOverText.text = "";
        }

        // Update is called once per frame
        void Update()
        {
            if (_score == 10)
            {
                GameOver(true);
            }
        }

        public static void IncrementScore()
        {
            Singleton.IncrementScoreInternal();
        }

        private void IncrementScoreInternal()
        {
            _score++;
            scoreText.text = $"Score: {_score}";
        }
        public static void GameOver(bool win)
        {
            Singleton.GameOverInternal(win);
        }

        private void GameOverInternal(bool win)
        {
            if (win)
            {
                gameOverText.text = "You Win!";
            }
            else
            {
                gameOverText.text = "You Lose!";
            }
        }
    }

}
