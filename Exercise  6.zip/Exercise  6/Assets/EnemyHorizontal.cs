using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public float moveSpeed = 5.0f;
    private Rigidbody2D _rb;

    // Start is called before the first frame update
    void Start()
    {
        _rb = GetComponent<Rigidbody2D>();
        _rb.velocity = new Vector2(moveSpeed, 0);
    }

    // Update is called once per frame
    void Update()
    {
        if (moveSpeed > 0)
        {
            GetComponent<SpriteRenderer>().flipX = false;
        } else
        {
            GetComponent<SpriteRenderer>().flipX = true;
        }
    }
    void OnCollisionEnter2D(Collision2D collision)
    {
        // TODO
        if (collision.collider.gameObject.GetComponent<Ground>())
        {
            moveSpeed *= -1;
            _rb.velocity = new Vector2(moveSpeed, 0);
        }
    }
}
